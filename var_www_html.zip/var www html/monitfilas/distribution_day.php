<?php
/*
   Copyright 2007, 2008 Nicolás Gudiño

   This file is part of Asternic Call Center Stats.

    Asternic Call Center Stats is free software: you can redistribute it
    and/or modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    Asternic Call Center Stats is distributed in the hope that it will be
    useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Asternic Call Center Stats.  If not, see
    <http://www.gnu.org/licenses/>.
*/

require_once("config.php");
//include("sesvars.php");
date_default_timezone_set("America/Sao_Paulo");
?>
<!-- http://www.house.com.ar/quirksmode -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php require_once('header_conf.php');?>
<!--<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title>Asternic Call Center Stats</title>
        <style type="text/css" media="screen">@import "css/basic.css";</style>
        <style type="text/css" media="screen">@import "css/tab.css";</style>
        <style type="text/css" media="screen">@import "css/table.css";</style>
        <style type="text/css" media="screen">@import "css/fixed-all.css";</style>
-->
        <script type="text/javascript" src="js/flashobject.js"></script>
        <script type="text/javascript" src="js/sorttable.js"></script>

<!--  //////////// Biblioteca CHART     ///////// -->

    <script src="chart/Chart.min.js"></script>

    <style type="text/css">

    *{
        font-family: calibri;
    }

    .box {
        margin: 0px auto;
        width: 50%;
    }

    .box-chart {
        width: 80%;
        margin: 0 auto;
        padding: 10px;
    }
/* ///////// LEGENDA ULTIMO GRAFICO ////////////////      */
    .chart-legend li span{
    display: inline-block;
    width: 12px;
    height: 12px;
    margin-right: 5px;
    }

     ul.a {
         list-style: none;
         margin-left: 0;
         padding-left: 1em;
         text-indent: -1em;
      }

    </style>

<!--[if gte IE 5.5000]>
<style type='text/css'> img { behavior:url(pngbehavior.htc) } </style>
<![endif]-->

<!--[if IE]>
<link
 href="css/fixed-ie.css"
 rel="stylesheet"
 type="text/css"
 media="screen">
<script type="text/javascript">
onload = function() { content.focus() }
</script>
<![endif]-->
</head>
<body>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['call_distrib_day']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

                        <TABLE class="table table-striped table-bordered bootstrap-datatable datatable responsive">
                                <THEAD>
                                <TR>
                                        <TH><?php echo $lang["$language"]['date']?></TH>
                                        <TH><?php echo $lang["$language"]['answered']?></TH>
                                        <TH>Fila</TH>
                                        <TH><?php echo $lang["$language"]['percent_answered']?></TH>
                                        <TH><?php echo $lang["$language"]['unanswered']?></TH>
                                        <TH><?php echo $lang["$language"]['percent_unanswered']?></TH>
                                        <TH><?php echo $lang["$language"]['avg_calltime']?></TH>
                                        <TH><?php echo $lang["$language"]['avg_holdtime']?></TH>
                                        <TH><?php echo $lang["$language"]['login']?></TH>
                                        <TH><?php echo $lang["$language"]['logoff']?></TH>
                                </TR>
                                </THEAD>
                                <TBODY>
<?php

$graphcolor = "&bgcolor=0xF0ffff&bgcolorchart=0xdfedf3&fade1=ff6600&fade2=ff6314&colorbase=0xfff3b3&reverse=1";
$graphcolorstack = "&bgcolor=0xF0ffff&bgcolorchart=0xdfedf3&fade1=ff6600&colorbase=fff3b3&reverse=1&fade2=0x528252";

// ABANDONED CALLS
$start = '2013-09-30';
//

$query = "SELECT qs.datetime AS datetime, q.queue AS qname, ag.agent AS qagent, ac.event AS qevent, ";
$query.= "qs.info1 AS info1, qs.info2 AS info2,  qs.info3 AS info3 FROM queue_stats AS qs, qname AS q, ";
$query.= "qagent AS ag, qevent AS ac WHERE qs.qname = q.qname_id AND qs.qagent = ag.agent_id AND ";
$query.= "qs.qevent = ac.event_id AND qs.datetime >= '$start 00:00:00' AND qs.datetime <= '$start 23:59:59'";
//$query.= "AND q.queue IN ($queue,'NONE') AND ac.event IN ('ABANDON', 'EXITWITHTIMEOUT','COMPLETECALLER','COMPLETEAGENT','AGENTLOGIN','AGENTLOGOFF','AGENTCALLBACKLOGIN','AGENTCALLBACKLOGOFF') ";
$query.= "AND ac.event IN ('ABANDON', 'EXITWITHTIMEOUT','COMPLETECALLER','COMPLETEAGENT','AGENTLOGIN','AGENTLOGOFF','AGENTCALLBACKLOGIN','AGENTCALLBACKLOGOFF') ";
$query.= "ORDER BY qs.datetime";

$query_comb     = "";
$login          = 0;
$logoff         = 0;
$dias           = Array();
$logout_by_day  = Array();
$logout_by_hour = Array();
$logout_by_dw   = Array();
$login_by_day   = Array();
$login_by_hour  = Array();
$login_by_dw    = Array();

$res2 = consulta_db($query,$DB_DEBUG,$DB_MUERE);
$res = consulta_db($query,$DB_DEBUG,$DB_MUERE);

if(db_num_rows($res2)>0) {
        while($row2=db_fetch_row($res2)) {

        $fila[] = $row2[1]; 

}
$fila = array_unique($fila);
$fila = implode($fila, ",");
$fila = explode(",", $fila);
print_r($fila);
echo "<br>";
$vl_fila = count($fila);
$ok=0;
while($vl_fila > $ok){
$queue = $fila[$ok];

//print_r($fila[$ok]);
//echo "<br>";
//echo $ok;

////////////////////////////////////////////////////////////////////////////////
//$query2 = "SELECT qs.datetime AS datetime, q.queue AS qname, ag.agent AS qagent, ac.event AS qevent, ";
//$query2.= "qs.info1 AS info1, qs.info2 AS info2,  qs.info3 AS info3 FROM queue_stats AS qs, qname AS q, ";
//$query2.= "qagent AS ag, qevent AS ac WHERE qs.qname = q.qname_id AND qs.qagent = ag.agent_id AND ";
//$query2.= "qs.qevent = ac.event_id AND qs.datetime >= '$start 00:00:00' AND qs.datetime <= '$start 23:59:59'";
//$query2.= "AND q.queue IN ($queue,'NONE') AND ac.event IN ('ABANDON', 'EXITWITHTIMEOUT','COMPLETECALLER','COMPLETEAGENT','AGENTLOGIN','AGENTLOGOFF','AGENTCALLBACKLOGIN','AGENTCALLBACKLOGOFF') ";
//$query2.= "ORDER BY qs.datetime";
////////////////////////////////////////////////////////////////////////////////
//$hostname_coon = "127.0.0.1";
//$database_coon = "qstats";
//$username_coon = "root";
//$password_coon = "!@#aztell!@#";
//$coon = mysql_connect($hostname_coon, $username_coon, $password_coon) or trigger_error(mysql_error(),E_USER_ERROR);
//mysql_select_db($database_coon, $coon);
//$res = mysql_query($query2);


print_r($queue);
echo "<br>";
//if(db_num_rows($res,$query2)>0) {

        while($row=db_fetch_row($res)) {
if($row[1] == $fila[$ok]){
                $partes_fecha = split(" ",$row[0]);
                $partes_hora  = split(":",$partes_fecha[1]);

                $timestamp = return_timestamp($row[0]);
                $day_of_week = date('w',$timestamp);

                $dias[] = $partes_fecha[0];
                $horas[] = $partes_hora[0];

                if($row[3]=="ABANDON" || $row[3]=="EXITWITHTIMEOUT") {
                        $unanswered++;
                        $unans_by_day["$partes_fecha[0]"]++;
                        $unans_by_hour["$partes_hora[0]"]++;
                        $unans_by_dw["$day_of_week"]++;
                }
                if($row[3]=="COMPLETECALLER" || $row[3]=="COMPLETEAGENT") {
                        $answered++;
                        $ans_by_day["$partes_fecha[0]"]++;
                        $ans_by_hour["$partes_hora[0]"]++;
                        $ans_by_dw["$day_of_week"]++;

                        $total_time_by_day["$partes_fecha[0]"]+=$row[5];
                        $total_hold_by_day["$partes_fecha[0]"]+=$row[4];

                        $total_time_by_dw["$day_of_week"]+=$row[5];
                        $total_hold_by_dw["$day_of_week"]+=$row[4];

                        $total_time_by_hour["$partes_hora[0]"]+=$row[5];
                        $total_hold_by_hour["$partes_hora[0]"]+=$row[4];
                }
                if($row[3]=="AGENTLOGIN" || $row[3]=="AGENTCALLBACKLOGIN") {
                        $login++;
                        $login_by_day["$partes_fecha[0]"]++;
                        $login_by_hour["$partes_hora[0]"]++;
                        $login_by_dw["$day_of_week"]++;
                }
                if($row[3]=="AGENTLOGOFF" || $row[3]=="AGENTCALLBACKLOGOFF") {
                        $logoff++;
                        $logout_by_day["$partes_fecha[0]"]++;
                        $logout_by_hour["$partes_hora[0]"]++;
                        $logout_by_dw["$day_of_week"]++;
                }

            }
        }
        $total_calls = $answered + $unanswered;
        $dias  = array_unique($dias);
        $horas = array_unique($horas);
    asort($dias);
        asort($horas);

//} else {
        // No rows returned
//        $answered = 0;
//        $unanswered = 0;
//}


$start_parts = split(" ", $start);
$end_parts   = split(" ", $end);

$cover_pdf = $lang["$language"]['queue'].": ".$queue."\n";
$cover_pdf.= $lang["$language"]['start'].": ".$start_parts[0]."\n";
$cover_pdf.= $lang["$language"]['end'].": ".$end_parts[0]."\n";
$cover_pdf.= $lang["$language"]['period'].": ".$period." ".$lang["$language"]['days']."\n\n";
$cover_pdf.= $lang["$language"]['number_answered'].": ".$answered." ".$lang["$language"]['calls']."\n";
$cover_pdf.= $lang["$language"]['number_unanswered'].": ".$unanswered." ".$lang["$language"]['calls']."\n";
$cover_pdf.= $lang["$language"]['agent_login'].": ".$login."\n";
$cover_pdf.= $lang["$language"]['agent_logoff'].": ".$logoff."\n";

?>
                                <?php
                                $header_pdf=array($lang["$language"]['date'],$lang["$language"]['answered'],$lang["$language"]['percent_answered'],$lang["$language"]['unanswered'],$lang["$language"]['percent_unanswered'],$lang["$language"]['avg_calltime'],$lang["$language"]['avg_holdtime'],$lang["$language"]['login'],$lang["$language"]['logoff']);
                                $width_pdf=array(25,23,23,23,23,25,25,20,20);
                                $title_pdf=$lang["$language"]['call_distrib_day'];

                                $count=1;
                                foreach($dias as $key) {
                                        $cual = $count%2;
                                        if($cual>0) { $odd = " class='odd' "; } else { $odd = ""; }
                                        if(!isset($ans_by_day["$key"])) {
                                                $ans_by_day["$key"]=0;
                                        }
                                        if(!isset($unans_by_day["$key"])) {
                                                $unans_by_day["$key"]=0;
                                        }
                                        if($answered > 0) {
                                                $percent_ans   = $ans_by_day["$key"]   * 100 / $answered;
                                        } else {
                                                $percent_ans = 0;
                                        }
                                        if($ans_by_day["$key"] >0) {
                                                $average_call_duration = $total_time_by_day["$key"] / $ans_by_day["$key"];
                                                $average_hold_duration = $total_hold_by_day["$key"] / $ans_by_day["$key"];
                                        } else {
                                                $average_call_duration = 0;
                                                $average_hold_duration = 0;
                                        }
                                        if($unanswered > 0) {
                                                $percent_unans = $unans_by_day["$key"] * 100 / $unanswered;
                                        } else {
                                                $percent_unans = 0;
                                        }
                                        $percent_ans   = number_format($percent_ans,  2);
                                        $percent_unans = number_format($percent_unans,2);
                                        $average_call_duration_print = seconds2minutes($average_call_duration);
                                        if($key<>"") {
                                        $linea_pdf = array($key,$ans_by_day["$key"],"$percent_ans ".$lang["$language"]['percent'],$unans_by_day["$key"],"$percent_unans ".$lang["$language"]['percent'],$average_call_duration_print,number_format($average_hold_duration,0),$login_by_day["$key"],$logout_by_day["$key"]);
//print_r($);
                                        echo "<TR $odd>\n";
                                        echo "<TD>$key</TD>\n";
                                        echo "<TD>".$ans_by_day["$key"]."</TD>\n";
                                        echo "<TD>".$fila[$ok]."</TD>\n";
                                        echo "<TD>$percent_ans ".$lang["$language"]['percent']."</TD>\n";
                                        echo "<TD>".$unans_by_day["$key"]."</TD>\n";
                                        echo "<TD>$percent_unans".$lang["$language"]['percent']."</TD>\n";
                                        echo "<TD>".$average_call_duration_print." ".$lang["$language"]['minutes']."</TD>\n";
                                        echo "<TD>".number_format($average_hold_duration,0)." ".$lang["$language"]['secs']."</TD>\n";
                                        echo "<TD>".$login_by_day["$key"]."</TD>\n";
                                        echo "<TD>".$logout_by_day["$key"]."</TD>\n";
                                        echo "</TR>\n";
                                        $count++;
                                        $data_pdf[]=$linea_pdf;
                                        }
                                }


////////////////////////////////////////////////////////////////////////////////
$ok++;
}
}
////////////////////////////////////////////////////////////////////////////////

                                ?>
                        </TBODY>
                        </TABLE>

                        <?php

                                if($count>1) {
                                        print_exports($header_pdf,$data_pdf,$width_pdf,$title_pdf,$cover_pdf);
                                }
                        ?>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->

</body>
<?php require_once('footer_conf.php');?>
</html>

