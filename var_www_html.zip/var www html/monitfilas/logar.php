<?php
 include_once('conexao.php');

session_start();

$usr = $_POST['login'];
$pwd = $_POST['senha'];
///////////////////////////////////////////

//$coon = mysql_connect($host, $user, $pass) or trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($db, $coon);
///////////////////////////////////////////
$sql = mysql_query("select * from `azcall`.`usuarios` where `usuarios`.`login`='".$usr."' and `usuarios`.`senha`='".$pwd."'");

if(mysql_num_rows($sql) > 0 ){

$_SESSION['login'] = $usr;
$_SESSION['senha'] = $pwd;
//echo "entrou";
//sleep(1);
//header('location:envia.php');
header('location:index.php');

} else {
unset($_SESSION['login']);
unset($_SESSION['senha']);
//echo "nao-entrou";
//sleep(1);
header('location:login.php');

}
?>
