<?php
v
?>
<head>
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
<!--    <link rel="stylesheet" href="style/screen.css" type="text/css" media="screen" />-->
        <link rel="shortcut icon" href="templates/images/favicon.ico" />
<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
    <link id="bs-css" href="dist/css/bootstrap-cerulean.min.css" rel="stylesheet">
  <!-- Bootstrap 3.3.6 -->
<!--
    <link href='bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='dist/css/jquery.noty.css' rel='stylesheet'>
    <link href='dist/css/noty_theme_default.css' rel='stylesheet'>
    <link href='dist/css/elfinder.min.css' rel='stylesheet'>
    <link href='dist/css/elfinder.theme.css' rel='stylesheet'>
    <link href='dist/css/uploadify.css' rel='stylesheet'>
    <link href='dist/css/animate.min.css' rel='stylesheet'>
    <link href='dist/css/funkradio.css' rel='stylesheet'>

    <link rel="stylesheet" href="dist/css/bootstrap-datetimepicker.min.css">


    <link rel="stylesheet" href="./dist/css/bootstrap-toggle.min.css">
    <script src="./dist/js/bootstrap-toggle.min.js" type="text/javascript"></script>
-->
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
        <link href="assets/css/gsdk.css" rel="stylesheet" />
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--     Font Awesome     -->
    <link href="bootstrap3/css/font-awesome.css" rel="stylesheet">



  <script src="js/bootstrap-checkbox.min.js" defer></script>
    <!-- ALL OF THE THEMES -->
    <!-- <link rel="stylesheet" href="css/toggles-all.css"> -->

    <!-- ALL OF THE CSS AND THEMES IN ONE FILE -->
    <!-- <link rel="stylesheet" href="css/toggles-full.css"> -->

<!--	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>-->
<!--  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
<!--  <link rel="stylesheet" href="dist/css/AdminLTE.min.css"> -->
<!--  <link rel="stylesheet" href="dist/css/charisma-app.css"> -->
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
<!--  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">-->
    <!-- jQuery -->
  <link rel="stylesheet" href="dist/css/chosen.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<!--<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">-->
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>-->
<!--	<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>-->
<!--  <script src=js/bootstrap.min.js"></script>-->
<!--    <script src="js/jquery.min.js"></script>--> 
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script src="bower_components/jquery/jquery.min.js"></script> 
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

    <script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>

	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-checkbox.js"></script>
	<script src="assets/js/gsdk-radio.js"></script>
	<script src="assets/js/gsdk-bootstrapswitch.js"></script>
	<script src="assets/js/get-shit-done.js"></script>
    <script src="assets/js/custom.js"></script>

<script type="text/javascript">
         
    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();
    $('.pick-class-label').click(function(){
        var new_class = $(this).attr('new-class');  
        var old_class = $('#display-buttons').attr('data-class');
        var display_div = $('#display-buttons');
        if(display_div.length) {
        var display_buttons = display_div.find('.btn');
        display_buttons.removeClass(old_class);
        display_buttons.addClass(new_class);
        display_div.attr('data-class', new_class);
        }
    });
    $( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
	});
	$( "#slider-default" ).slider({
			value: 70,
			orientation: "horizontal",
			range: "min",
			animate: true
	});
	$('.carousel').carousel({
      interval: 4000
    });
      
    
</script>

        <script language='JavaScript'>
                function NewDate( cur_date ) {
                        var curr = new Date; // get current date
                        var first;
                        var last;

                        if ( cur_date == 'tw' ) {
                                first = curr.getDate() - curr.getDay()+1;
                                last = new Date(curr.setDate(first+6));
                                first = new Date(curr.setDate(first));
                        } else if ( cur_date == 'pw' ) {
                                first = curr.getDate() - 7 - curr.getDay() + 1;
                                last = new Date(curr.setDate(first+6));
                                first = new Date(curr.setDate(first));
                        } else if ( cur_date == '3w' ) {
                                first = curr.getDate() - 14 - curr.getDay() + 1;
                                last = new Date(curr.setDate(first+20));
                                first = new Date(curr.setDate(first));
                        } else if ( cur_date == 'td' ) {
                                first = curr.getDate();
                                last = new Date(curr.setDate(first));
                                first = new Date(curr.setDate(first));
                        } else if ( cur_date == 'pd' ) {
                                first = curr.getDate()-1;
                                last = new Date(curr.setDate(first));
                                first = new Date(curr.setDate(first));
                        } else if ( cur_date == '3d' ) {
                                first = curr.getDate()-2;
                                last = new Date(curr.setDate(first+2));
                                first = new Date(curr.setDate(first));
                        } else if ( cur_date == 'tm' ) {
                                last = new Date(curr.getFullYear(), curr.getMonth() + 1, 0);
                                first = new Date(curr.getFullYear(), curr.getMonth(), 1);
                        } else if ( cur_date == 'pm' ) {
                                last = new Date(curr.getFullYear(), curr.getMonth(), 0);
                                first = new Date(curr.getFullYear(), curr.getMonth()-1, 1);
                        } else if ( cur_date == '3m' ) {
                                last = new Date(curr.getFullYear(), curr.getMonth()+1, 0);
                                first = new Date(curr.getFullYear(), curr.getMonth()-2, 1);
                        }

                        if ( typeof(first) !== 'undefined' ) {
                                document.getElementById("startmonth").selectedIndex = first.getMonth();
                                document.getElementById("startday").value = first.getDate();

                                var selector = document.getElementById('startyear');
                                for ( i = selector.options.length-1; i>=0; i-- ) {
                                        if ( selector.options[i].value == first.getFullYear() ) {
                                                selector.selectedIndex=i;
                                                break;
                                        }
                                }
                                document.getElementById("endmonth").selectedIndex = last.getMonth();
                                document.getElementById("endday").value = last.getDate();

                                selector = document.getElementById('endyear');
                                for ( i = selector.options.length-1; i>=0; i-- ) {
                                        if ( selector.options[i].value == last.getFullYear() ) {
                                                selector.selectedIndex=i;
                                                break;
                                        }
                                }
                        }
                }
//////////////////////////////////////////////////
//////////////////////////////////////////////////

        </script>
    <script src="chart/Chart.min.js"></script>
    <style type="text/css">
    .chart-legend li span{
    display: inline-block;
    width: 12px;
    height: 12px;
    margin-right: 5px;
    }

    *{
        font-family: calibri;
    }

    .boxer {
        margin: 0px auto;
        width: 70%;
    }

    .boxer-chart {
        width: 100%;
        margin: 0 auto;
        padding: 10px;
    }

    </style>




