<?php
//$username = $_GET['username'];
$username = isset($_GET['username'])? $_GET['username'] : NULL;

  if($username) {
       //save new user to database  
echo "<tr>";
echo "<td>$username</td>";
echo "</tr>";
  }

//STEP2. pick all the users from database

//STEP3. return all the users obtained from Databse.

?>

