<!DOCTYPE html>

<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">

    <title>Chart.js - criando gráficos com a biblioteca Chart.js</title>

    <script src="Chart.min.js"></script>

    <style type="text/css">

    *{
        font-family: calibri;        
    }

    .box {
        margin: 0px auto;
        width: 70%;
    }

    .box-chart {
        width: 100%;
        margin: 0 auto;
        padding: 10px;
    }

    </style>  

    <script type="text/javascript">
        var randomnb = function(){ return Math.round(Math.random()*220)};
    </script>  

</head>

<body>    

        <div class="box-chart">
            <canvas id="GraficoBarra" style="width:100%;"></canvas>
            <script type="text/javascript">                                        
                var options = {
                    responsive:true
                };
                var data = {
<? 
$i="0";
$r="18";
// while( $i < 6 ){
?>
                    labels: [<? while( $i < 6 ){echo "".$i.",";$i++;}?>],
<?
//$i++;
//}?>
                    datasets: [
                        {
                            label: "Dados primários",
                            fillColor: "rgba("+randomnb()+","+randomnb()+","+randomnb()+",0.5)",
                            strokeColor: "rgba("+randomnb()+","+randomnb()+","+randomnb()+",0.8)",
                            highlightFill: "rgba("+randomnb()+","+randomnb()+","+randomnb()+",0.75)",
                            highlightStroke: "rgba("+randomnb()+","+randomnb()+","+randomnb()+",1)",
                            data: ["12","13","9","3","7","14"]
                        }
                    ]
                };                

                window.onload = function(){
                    var ctx = document.getElementById("GraficoBarra").getContext("2d");
                    var BarChart = new Chart(ctx).Bar(data, options);
                }           
            </script>

        </div>
    
</body>
<??>
</html>
