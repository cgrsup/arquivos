<?php
$r=shell_exec("sudo  cat log.log");

echo "</ br> ".$r."\n";
?>
