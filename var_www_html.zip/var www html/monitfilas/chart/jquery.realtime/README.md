# jQuery Realtime - write less, do realtime

The jQuery realtime library is a first attempt at making it really easy for anybody to add realtime data to a web page by just adding markup to a page and using jQuery and a jQuery library.

The jQuery Realtime library uses [Pusher](http://pusher.com).

You can read more about this plugin, and see an example of it in action in this [jQuery Realtime Markup blog post](http://leggetter.github.io/jquery.realtime/examples/blog.html).
