<?php
	if (!isset($_SESSION)) { 
		session_start();
	}	
	include_once("../modelo/Funcionario.class.php");
	include_once("../modelo/Operador.class.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Gerador de CAMPANHA</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<link rel="stylesheet" href="../css/mm_lodging1.css" type="text/css" />
<link rel="stylesheet" href="../../css/geral.css" />
<link rel="stylesheet" href="../../css/paginasInternas.css" />-->
 <!-- The styles -->
    <link id="bs-css" href="../css/bootstrap-cerulean.min.css" rel="stylesheet">
    <link href="../css/charisma-app.css" rel="stylesheet">
    <link href='../bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='../bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='../bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='../bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='../bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='../bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='../css/jquery.noty.css' rel='stylesheet'>
    <link href='../css/noty_theme_default.css' rel='stylesheet'>
    <link href='../css/elfinder.min.css' rel='stylesheet'>
    <link href='../css/elfinder.theme.css' rel='stylesheet'>
    <link href='../css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='../css/uploadify.css' rel='stylesheet'>
    <link href='../css/animate.min.css' rel='stylesheet'>
    <link href='../css/bootstrap-cerulean.min.css' rel='stylesheet'>
    <!-- jQuery -->
<!--    <script src="../bower_components/jquery/jquery.min.js"></script>
-->

 <script type="text/javascript" src="jquery-1.3.2.min.js"></script>
    <script type="text/javascript" src="jquery.periodicalupdater.js"></script>
    <script src="Chart.min.js"></script>

<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
-->
</style>
<style type="text/css">
/*               #wrapper{
            width:800px;
            margin:0 auto;
        }

        #content{
            background-color:white;
            text-align:justify;
            padding:10px;
            border: 1px solid #BBB;
        }
*/
        #results{
            height:600px;
            overflow:auto;
        }
/*
        h1, h2, h3{
            color: #49176D;
        }
*/</style>

<script type="text/javascript">
    <!--
        $(document).ready(function(){

            $.PeriodicalUpdater({
//                    url : 'status.php',
                    url : 'pie.html',
//                    method: 'post',
                    type : 'text',
                    maxTimeout: 3000
                },
                function(data){
                    var myHtml =  data;
                    $('#results').append(myHtml);
            });
/*
            $('a#stop').click(function(e){
                e.preventDefault();
                clearTimeout(PeriodicalTimer);

                var html = '<p name="ajaxstopped">Ajax requests from $.PeriodicalUpdater have been stopped!</p>';
                $('a#stop').after(html);
                $('p[name="ajaxstopped"]').css({color: 'red'}).fadeOut(300).fadeIn(300).fadeOut(300).fadeIn(300);
                $(this).slideUp(500);
            })*/
        })
    -->
/* $.PeriodicalUpdater({
  url : 'teste.php',
  type: 'text'


 },
   function(data){
        if(data!=0){
            $("#counto").load("teste.php");
        }else{
           $("#counto").empty();
       }
   });
   $.PeriodicalUpdater({
      url : 'teste.php',
      type: 'text'
   },
   function(d){
       if(d!=0){
            $("#countu").load("teste.php");
       }else{
           $("#countu").empty();
       }
   });
*/
    </script>
</head>
<body>
        <table class="table table-striped table-bordered" border="0" cellspacing="0" cellpadding="0" width="100%">
                <tr>
                <td><center><p><h3>Log de envio..</h3></p></center></td>
                </tr>

                <tr>
                <td class="bodyText">

<div id="content">
            <h1>&nbsp;</h1>



            <div class="animated zoomIn" id="results">
                <h4>Monitor:</h4>
            </div>


            <a href="#" id="stop">Parar Log!</a>
        </div>

<div align="justify"><br />
                  </div></td>
                </tr>
  </tr>
</table>
</body>
</html>
