<?php 
/*
   Copyright 2007, 2008 Nicolás Gudiño

   This file is part of Asternic Call Center Stats.

    Asternic Call Center Stats is free software: you can redistribute it 
    and/or modify it under the terms of the GNU General Public License as 
    published by the Free Software Foundation, either version 3 of the 
    License, or (at your option) any later version.

    Asternic Call Center Stats is distributed in the hope that it will be 
    useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Asternic Call Center Stats.  If not, see 
    <http://www.gnu.org/licenses/>.
*/

if(!isset($_GET['auth'])){
echo "<script language='javascript'>
   <!--
    alert('Sem autorizacao de acesso!');
    //-->
window.close();
    </script>";
}

require_once("config.php");
include("sesvars.php");
?>
<!-- http://www.house.com.ar/quirksmode -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php require_once('header_conf.php');?>

       <script language='javascript'>

 $(document).ready(function(){
        setInterval(function(){
                $("#results").load('auxstate_helper2.php')
    }, 2000);
});


        </script>
<style type="text/css">
        #results{
            height:100%;
            overflow:auto;
        }
</style>
</head>
<body>
<?php // include("menu.php"); ?>
<div id="main">
        <div id="contents" style='min-width: 900px'>
<div style='min-width: 870px'>
<center>
<?php
echo "<h2>".$lang[$language]['current_agent_status']."</h2>";

?>
<div id='results'>
</div>
</center>

</div>
</div>
</div>
</body>
<?php //require_once('footer2_conf.php');?>

</html>
