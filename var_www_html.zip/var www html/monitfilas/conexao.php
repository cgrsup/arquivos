<?php
$host="127.0.0.1";
$db="azcall";
$user="root";
$pass="ide973@Cd";

$coon = mysql_connect($host, $user, $pass) or trigger_error(mysql_error(),E_USER_ERROR);

?>
