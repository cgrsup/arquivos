<script type="text/javascript">

$(document).ready(function(){
    $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
        localStorage.setItem('activeTab', $(e.target).attr('href'));
    });
    var activeTab = localStorage.getItem('activeTab');
    if(activeTab){
        $('#myTab a[href="' + activeTab + '"]').tab('show');
    }
});


    $(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){

        $.post("set_sesvar.php", { sesvar: "hideloggedoff", value: "true"});
//        alert("Dongle "+id3+" aplicado em 3G com sucesso");
            }
            else if($(this).prop("checked") == false){
        $.post("set_sesvar.php", { sesvar: "hideloggedoff", value: "false"});
//                alert("Checkbox is unchecked.");
            }
        });
    });
function aplica(md2) {

        var id3 = md2.id

//        $.post("3g.php",{ gsm: id3});
//        alert("abre");
        $.post("set_sesvar.php", { sesvar: "hideloggedoff", value: "true"});
//    console.log(e.target.checked);
//      return false;


}
function naoaplica(md2) {

        var id3 = md2.id

//        $.post("3g.php",{ gsm: id3});
        $.post("set_sesvar.php", { sesvar: "hideloggedoff", value: "false"});
//        alert("fecha");
//      return false;


}


        </script>
<?php
date_default_timezone_set("America/Sao_Paulo");
/*
   Copyright 2007, 2008 Nicolás Gudiño

   This file is part of Asternic Call Center Stats.

    Asternic Call Center Stats is free software: you can redistribute it 
    and/or modify it under the terms of the GNU General Public License as 
    published by the Free Software Foundation, either version 3 of the 
    License, or (at your option) any later version.

    Asternic Call Center Stats is distributed in the hope that it will be 
    useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Asternic Call Center Stats.  If not, see 
    <http://www.gnu.org/licenses/>.
*/

$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$begintime = $time;
$inuse      = Array();
$dict_queue = Array();

require("config.php");
require("asmanager.php");
require("realtime_functions.php");
if(isset($_SESSION['QSTATS']['hideloggedoff'])) {
    $ocultar= $_SESSION['QSTATS']['hideloggedoff'];
    $select_menu= $_SESSION['QSTATS']['select_menu'];
} else {
    $ocultar="false";
    $select_menu="false";
}
if(isset($_SESSION['QSTATS']['filter'])) {
    $filter= $_SESSION['QSTATS']['filter'];
} else {
    $filter="";
}


?>
<!--<input type='checkbox' name='hidelogedoff' <?php if($ocultar=="true"){ echo "checked";}?>  data-toggle='switch' class='ct-green'/> --><?php //echo $lang[$language]['hide_loggedoff']."\n";

echo "<label> Agentes Desconectados</label><br>";
if($ocultar=="false"){
echo "<button type='button' onclick='aplica(this);' id='ISO' class='btn btn-default btn-round' ><i class='glyphicon glyphicon-eye-close'></i>  Ocultar</button>";
}
if($ocultar=="true"){
echo "<button type='button' onclick='naoaplica(this);' id='ISO' class='btn btn-success btn-round '><i class='glyphicon glyphicon-eye-open'></i>  Mostrar</button>";
}
echo "<a class='btn btn-default btn-round' href='' onClick=\"javascript:window.open ('realtime2.php?auth=a2e63ee01401aaeca78be023dfbb8c59','popup','width=1000,height=800')\" data-content='Abrindo monitoramento...'><i class='glyphicon glyphicon-fullscreen ' style ='color: blue;'></i> Maximizar Monitor </a>";
echo "<br>";
//print_r($ocultar);
echo "<br>";

$am=new AsteriskManager();
$am->connect($manager_host,$manager_user,$manager_secret);

$channels = get_channels ($am);
//echo "<pre>";print_r($channels);echo "</pre>";
foreach($channels as $ch=>$chv) {
  list($chan,$ses) = split("-",$ch,2);
  $inuse["$chan"]=$ch;
}

$queues		= get_queues   ($am,$channels);
$queues_menu	= get_queues   ($am,$channels);
$queues2	= get_queues   ($am,$channels);
//echo "<pre> queue";print_r($queues);echo "</pre>";

foreach ($queues as $key=>$val) {
  $queue[] = $key;
  $queue_menu[] = $key;
}

//echo "<input type=checkbox name='hidelogedoff' onClick='sethide(this)' ";
//if($ocultar=="true") echo " checked ";
//echo "> ".$lang[$language]['hide_loggedoff']."\n";

$ii=1;
$ie=1;
echo "  <br>";
echo "  <br>";
echo "  <br>";
	echo "<div class='container'>"; 
	echo "<ul class='nav nav-pills' id='myTab'>";

		echo "<li class='active'><a data-toggle='tab' href='#status'>Resumo</a></li>";
foreach($queue_menu as $qn_menu) {
//$teste .= $qn_menu."_$ie - ";
    if($filter=="" || stristr($qn_menu,$filter)) {
        $contador=1;
        if(!isset($queues_menu[$qn_menu]['members'])) continue;

        foreach($queues_menu[$qn_menu]['members'] as $key=>$val) {
            $stat="";
            $last="";
            $dur="";
            $clid="";
            $akey = $queues_menu[$qn_menu]['members'][$key]['agent'];
            $aname = $queues_menu[$qn_menu]['members'][$key]['name'];
            $aval = $queues_menu[$qn_menu]['members'][$key]['type'];
            if(array_key_exists($key,$inuse)) {
                if($aval=="not in use") {
                   $aval = "conversation";
                }
                if($channels[$inuse[$key]]['duration']=='') {
                   $newkey = $channels[$inuse[$key]]['bridgedto'];
                   $dur = $channels[$newkey]['duration_str'];
                   $clid = $channels[$newkey]['callerid'];
                } else {
                   $newkey = $channels[$inuse[$key]]['bridgedto'];
                   $clid = $channels[$newkey]['callerid'];
                   $dur = $channels[$inuse[$key]]['duration_str'];
                }
            }
            $stat = $queues_menu[$qn_menu]['members'][$key]['status'];
            $last = $queues_menu[$qn_menu]['members'][$key]['lastcall'];
            if(($aval == "unavailable" || $aval == "unknown") && $ocultar=="true") {
            } else {
                if($contador==1) {
		echo "<li><a data-toggle='tab' href='#".$qn_menu."_".$ie."'>".$qn_menu."</a></li>";
                }
                if($contador%2) { $odd="class='odd'"; } else { $odd=""; }
                if($last<>"") { $last=$last." ".$lang[$language]['min_ago']; } else { $last = $lang[$language]['no_info']; }
                $agent_name = agent_name($aname);
                if($stat<>"") $aval="paused";
                if(!array_key_exists($key,$inuse)) {
                    if($aval=="busy") $aval="not in use";
                }
                $aval2 = ereg_replace(" ","_",$aval);
                $mystringaval = $lang[$language][$aval2];
                                if($mystringaval=="") $mystringaval = $aval;
                $contador++;
            }
        
	}
      }

$ie++;
}

	echo "</ul>";
//print_r($_REQUEST);

         echo"<div class='tab-content'>";
echo "<div class='tab-pane active' id='status'>";
include("realtime_qsummary.php");
include("realtime_qdetail.php");
echo "</div>";
include("realtime_agents.php");
$time = microtime();
$time = explode(" ", $time);
$time = $time[1] + $time[0];
$endtime = $time;
$totaltime = ($endtime - $begintime);
echo "<br/><br/>".$lang[$language]['server_time']." ".date('Y-m-d H:i:s')."<br/>";
echo $lang[$language]['php_parsed']." $totaltime ".$lang[$language]['seconds'];
echo "</div>";
echo "</div>";
?>

