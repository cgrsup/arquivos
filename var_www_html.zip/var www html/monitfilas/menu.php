<?php 
/*
   Copyright 2007, 2008 Nicolás Gudiño

   This file is part of Asternic Call Center Stats.

    Asternic Call Center Stats is free software: you can redistribute it 
    and/or modify it under the terms of the GNU General Public License as 
    published by the Free Software Foundation, either version 3 of the 
    License, or (at your option) any later version.

    Asternic Call Center Stats is distributed in the hope that it will be 
    useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Asternic Call Center Stats.  If not, see 
    <http://www.gnu.org/licenses/>.
*/
?>
<div id="sidebar">&nbsp;</div>
<div id="content">
<a name='0'></a>
<div id='header'>
<!--<ul id='primary'>-->
  <ul class="nav nav-tabs">
<?php 
$menu[] = $lang["$language"]['menu_home'];
$menu[] = $lang["$language"]['menu_answered'];
$menu[] = $lang["$language"]['menu_unanswered'];
$menu[] = $lang["$language"]['menu_distribution'];
$menu[] = "Realtime";

$link[] = "index.php";
$link[] = "answered.php";
$link[] = "unanswered.php";
$link[] = "distribution.php";
$link[] = "realtime.php";

$anchor = Array();

if(basename($self)=="answered.php")
{

$anchor[]=$lang["$language"]['answered_calls_by_agent'];
$anchor[]=$lang["$language"]['call_response'];
$anchor[]=$lang["$language"]['answered_calls_by_queue'];
$anchor[]=$lang["$language"]['disconnect_cause'];
$b=1;
} elseif (basename($self) =="unanswered.php") {

$anchor1[]=$lang["$language"]['disconnect_cause'];
$anchor1[]=$lang["$language"]['unanswered_calls_qu'];
$b=2;
} elseif (basename($self) =="distribution.php") {
$b=3;
$anchor2[]=$lang["$language"]['call_distrib_day'];
$anchor2[]=$lang["$language"]['call_distrib_hour'];
$anchor2[]=$lang["$language"]['call_distrib_week'];
}

/*
for($a=0;$a<count($menu);$a++)
{
    if(basename($self)==$link[$a]) {
		echo "<li><span>".$menu[$a]."</span></li>\n";
		if(count($anchor)>0 && $a=$b) {
		   // echo "<ul id='secondary'>\n";
		    echo "<li class=\"dropdown\">\n";
			echo "<a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"".$menu[$a]."\">".$menu[$a]."<span class=\"caret\"></span></a>";
		          echo "<ul class=\"dropdown-menu\">\n";
			$contador=1;
			foreach ($anchor as $item) {
				echo "<li><a href='#$contador'>$item</a></li>\n";
				$contador++;
			}
		         echo "</ul>\n";
		    echo "</li>\n";
		}
	
	} else {
		if(isset($_SESSION['QSTATS']['start'])) {
		echo "<li><a href='".$link["$a"]."'>".$menu["$a"]." - ".basename($self)."</a></li>\n";
	}
    }
}*/

?>
    <li <?php if(basename($self)==$link[0]){ echo "class=\"active\""; } ?>><a href="<?php echo $link[0];?>"><?php echo $menu[0];?></a></li>


<?php                 if(!isset($_SESSION['QSTATS']['start'])) {
//                echo "<li><a href='".$link["$a"]."'>".$menu["$a"]." - ".basename($self)."</a></li>\n";
        } else {

      if(basename($self)!=$link[1]){ echo "<li><a href=\"$link[1]\">$menu[1]</a></li>"; } else { ?>
    <li class="dropdown active">
      <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $menu[1];?>   <i class="glyphicon glyphicon-menu-down"></i></a>
      <ul class="dropdown-menu">
<?php			$contador=1;
                         foreach ($anchor as $item) {
                                echo "<li><a href='#$contador'>$item</a></li>\n";
                                $contador++;
                        }?>
      </ul>
    </li>
<?php } ?>
<?php if(basename($self)!=$link[2]){ echo "<li><a href=\"$link[2]\">$menu[2]</a></li>"; } else { ?>
    <li class="dropdown active">
      <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $menu[2];?>   <i class="glyphicon glyphicon-menu-down"></i></a>
      <ul class="dropdown-menu">
<?php			$contador1=1;
                         foreach ($anchor1 as $item1) {
                                echo "<li><a href='#$contador1'>$item1</a></li>\n";
                                $contador1++;
                        }?>
      </ul>
    </li>
<?php } ?>
<?php if(basename($self)!=$link[3]){ echo "<li><a href=\"$link[3]\">$menu[3]</a></li>"; } else { ?>
    <li class="dropdown active">
      <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $menu[3];?>   <i class="glyphicon glyphicon-menu-down"></i></a>
      <ul class="dropdown-menu">
<?php			$contador2=1;
                         foreach ($anchor2 as $item2) {
                                echo "<li><a href='#$contador2'>$item2</a></li>\n";
                                $contador2++;
                        }?>
      </ul>
    </li>
<?php } ?>
    <li <?php if(basename($self)==$link[4]){ echo "class=\"active\""; } ?>><a href="<?php echo $link[4];?>"><?php echo $menu[4];?></a></li>

<?php } ?>
<li class="btn btn-xs pull-right" ><a href="logout.php">Limpar pesquisa <i class="glyphicon glyphicon-erase"></i></a> </li>
</ul>

</div>
