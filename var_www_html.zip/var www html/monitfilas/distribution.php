<?php 
/*
   Copyright 2007, 2008 Nicolás Gudiño

   This file is part of Asternic Call Center Stats.

    Asternic Call Center Stats is free software: you can redistribute it 
    and/or modify it under the terms of the GNU General Public License as 
    published by the Free Software Foundation, either version 3 of the 
    License, or (at your option) any later version.

    Asternic Call Center Stats is distributed in the hope that it will be 
    useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Asternic Call Center Stats.  If not, see 
    <http://www.gnu.org/licenses/>.
*/

require_once("config.php");
include("sesvars.php");
date_default_timezone_set("America/Sao_Paulo");
?>
<!-- http://www.house.com.ar/quirksmode -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php require_once('header_conf.php');?>
<!--<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Asternic Call Center Stats</title>
	<style type="text/css" media="screen">@import "css/basic.css";</style>
	<style type="text/css" media="screen">@import "css/tab.css";</style>
	<style type="text/css" media="screen">@import "css/table.css";</style>
	<style type="text/css" media="screen">@import "css/fixed-all.css";</style>
-->
	<script type="text/javascript" src="js/flashobject.js"></script>
	<script type="text/javascript" src="js/sorttable.js"></script>

<!--  //////////// Biblioteca CHART     ///////// -->

    <script src="chart/Chart.min.js"></script>

    <style type="text/css">

    *{
        font-family: calibri;
    }

    .box {
        margin: 0px auto;
        width: 50%;
    }

    .box-chart {
        width: 80%;
        margin: 0 auto;
        padding: 10px;
    }
/* ///////// LEGENDA ULTIMO GRAFICO ////////////////      */
    .chart-legend li span{
    display: inline-block;
    width: 12px;
    height: 12px;
    margin-right: 5px;
    }

     ul.a {
	 list-style: none;
	 margin-left: 0;
	 padding-left: 1em;
	 text-indent: -1em;
      }

    </style>

<!--[if gte IE 5.5000]>
<style type='text/css'> img { behavior:url(pngbehavior.htc) } </style>
<![endif]-->

<!--[if IE]>
<link 
 href="css/fixed-ie.css" 
 rel="stylesheet" 
 type="text/css" 
 media="screen"> 
<script type="text/javascript"> 
onload = function() { content.focus() } 
</script> 
<![endif]-->
</head>
<?php 

$graphcolor = "&bgcolor=0xF0ffff&bgcolorchart=0xdfedf3&fade1=ff6600&fade2=ff6314&colorbase=0xfff3b3&reverse=1";
$graphcolorstack = "&bgcolor=0xF0ffff&bgcolorchart=0xdfedf3&fade1=ff6600&colorbase=fff3b3&reverse=1&fade2=0x528252";

// ABANDONED CALLS

$query = "SELECT qs.datetime AS datetime, q.queue AS qname, ag.agent AS qagent, ac.event AS qevent, ";
$query.= "qs.info1 AS info1, qs.info2 AS info2,  qs.info3 AS info3 FROM queue_stats AS qs, qname AS q, ";
$query.= "qagent AS ag, qevent AS ac WHERE qs.qname = q.qname_id AND qs.qagent = ag.agent_id AND ";
$query.= "qs.qevent = ac.event_id AND qs.datetime >= '$start' AND qs.datetime <= '$end' ";
$query.= "AND q.queue IN ($queue,'NONE') AND ac.event IN ('ABANDON', 'EXITWITHTIMEOUT','COMPLETECALLER','COMPLETEAGENT','AGENTLOGIN','AGENTLOGOFF','AGENTCALLBACKLOGIN','AGENTCALLBACKLOGOFF') ";
$query.= "ORDER BY qs.datetime";

$query_comb     = "";
$login          = 0;
$logoff         = 0;
$dias           = Array();
$logout_by_day  = Array();
$logout_by_hour = Array();
$logout_by_dw   = Array();
$login_by_day   = Array();
$login_by_hour  = Array();
$login_by_dw    = Array();

$res = consulta_db($query,$DB_DEBUG,$DB_MUERE);

if(db_num_rows($res)>0) {

	while($row=db_fetch_row($res)) {
		$partes_fecha = split(" ",$row[0]);
		$partes_hora  = split(":",$partes_fecha[1]);

		$timestamp = return_timestamp($row[0]);
		$day_of_week = date('w',$timestamp);
			
		$dias[] = $partes_fecha[0];
		$horas[] = $partes_hora[0];

		if($row[3]=="ABANDON" || $row[3]=="EXITWITHTIMEOUT") {
 			$unanswered++;
			$unans_by_day["$partes_fecha[0]"]++;
			$unans_by_hour["$partes_hora[0]"]++;
			$unans_by_dw["$day_of_week"]++;
		}
		if($row[3]=="COMPLETECALLER" || $row[3]=="COMPLETEAGENT") {
 			$answered++;
			$ans_by_day["$partes_fecha[0]"]++;
			$ans_by_hour["$partes_hora[0]"]++;
			$ans_by_dw["$day_of_week"]++;

			$total_time_by_day["$partes_fecha[0]"]+=$row[5];
			$total_hold_by_day["$partes_fecha[0]"]+=$row[4];

			$total_time_by_dw["$day_of_week"]+=$row[5];
			$total_hold_by_dw["$day_of_week"]+=$row[4];
		
			$total_time_by_hour["$partes_hora[0]"]+=$row[5];
			$total_hold_by_hour["$partes_hora[0]"]+=$row[4];
		}
		if($row[3]=="AGENTLOGIN" || $row[3]=="AGENTCALLBACKLOGIN") {
 			$login++;
			$login_by_day["$partes_fecha[0]"]++;
			$login_by_hour["$partes_hora[0]"]++;
			$login_by_dw["$day_of_week"]++;
		}
		if($row[3]=="AGENTLOGOFF" || $row[3]=="AGENTCALLBACKLOGOFF") {
 			$logoff++;
			$logout_by_day["$partes_fecha[0]"]++;
			$logout_by_hour["$partes_hora[0]"]++;
			$logout_by_dw["$day_of_week"]++;
		}
	}
	$total_calls = $answered + $unanswered;
	$dias  = array_unique($dias);
	$horas = array_unique($horas);
    asort($dias);
	asort($horas);
} else {
 	// No rows returned
	$answered = 0;
	$unanswered = 0;
}


$start_parts = split(" ", $start);
$end_parts   = split(" ", $end);

$cover_pdf = $lang["$language"]['queue'].": ".$queue."\n";
$cover_pdf.= $lang["$language"]['start'].": ".$start_parts[0]."\n";
$cover_pdf.= $lang["$language"]['end'].": ".$end_parts[0]."\n";
$cover_pdf.= $lang["$language"]['period'].": ".$period." ".$lang["$language"]['days']."\n\n";
$cover_pdf.= $lang["$language"]['number_answered'].": ".$answered." ".$lang["$language"]['calls']."\n";
$cover_pdf.= $lang["$language"]['number_unanswered'].": ".$unanswered." ".$lang["$language"]['calls']."\n";
$cover_pdf.= $lang["$language"]['agent_login'].": ".$login."\n";
$cover_pdf.= $lang["$language"]['agent_logoff'].": ".$logoff."\n";
?>
<body>
<?php  include("menu.php"); ?>
<div class="ch-container">
<br>
    <div class="row">
        <div id="content" class="col-lg-12 col-sm-12">
<!--
<div id="main">
    <div id="contents">
-->
<!--        <TABLE width='99%' cellpadding=3 cellspacing=3 border=0>-->
    <div class="row">
        <div class="col-md-6">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['report_info']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

				<TABLE class="table table-striped table-bordered responsive">
				<TBODY>
				<TR>
					<TD><?php echo $lang["$language"]['queue']?>:</TD>
					<TD><?php echo $queue?></TD>
				</TR>
    	        </TR>
        	       	<TD><?php echo $lang["$language"]['start']?>:</TD>
            	   	<TD><?php echo $start_parts[0]?></TD>
				</TR>
    	        </TR>
        	    <TR>
            	   	<TD><?php echo $lang["$language"]['end']?>:</TD>
               		<TD><?php echo $end_parts[0]?></TD>
	            </TR>
    	        <TR>
        	       	<TD><?php echo $lang["$language"]['period']?>:</TD>
            	   	<TD><?php echo $period?> <?php echo $lang["$language"]['days']?></TD>
	            </TR>
				</TBODY>
				</TABLE>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->

        <div class="col-md-6">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['totals']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

				<TABLE class='table table-striped table-bordered responsive'>
				<TBODY>
		        <TR> 
                  <TD><?php echo $lang["$language"]['number_answered']?>:</TD>
		          <TD><?php echo $answered?> <?php echo $lang["$language"]['calls']?></TD>
	            </TR>
                <TR>
                  <TD><?php echo $lang["$language"]['number_unanswered']?>:</TD>
                  <TD><?php echo $unanswered?> <?php echo $lang["$language"]['calls']?></TD>
                </TR>
		        <TR>
                  <TD><?php echo $lang["$language"]['agent_login']?>:</TD>
		          <TD><?php echo $login?></TD>
	            </TR>
                <TR>
                  <TD><?php echo $lang["$language"]['agent_logoff']?>:</TD>
                  <TD><?php echo $logoff?></TD>
                </TR>
				</TBODY>
	          </TABLE>

</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->

		<BR>	
			<?php 
				if(count($dias)<=0) {
					$dias['']=0;
				}
			?>
			<a name='1'></a>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['call_distrib_day']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

			<TABLE class="table table-striped table-bordered bootstrap-datatable datatable responsive">
				<THEAD>
				<TR>
					<TH><?php echo $lang["$language"]['date']?></TH>
					<TH><?php echo $lang["$language"]['answered']?></TH>
					<TH><?php echo $lang["$language"]['percent_answered']?></TH>
					<TH><?php echo $lang["$language"]['unanswered']?></TH>
					<TH><?php echo $lang["$language"]['percent_unanswered']?></TH>
					<TH><?php echo $lang["$language"]['avg_calltime']?></TH>
					<TH><?php echo $lang["$language"]['avg_holdtime']?></TH>
					<TH><?php echo $lang["$language"]['login']?></TH>
					<TH><?php echo $lang["$language"]['logoff']?></TH>
				</TR>
				</THEAD>
				<TBODY>
				<?php 
				$header_pdf=array($lang["$language"]['date'],$lang["$language"]['answered'],$lang["$language"]['percent_answered'],$lang["$language"]['unanswered'],$lang["$language"]['percent_unanswered'],$lang["$language"]['avg_calltime'],$lang["$language"]['avg_holdtime'],$lang["$language"]['login'],$lang["$language"]['logoff']);
				$width_pdf=array(25,23,23,23,23,25,25,20,20);
				$title_pdf=$lang["$language"]['call_distrib_day'];

				$count=1;
				foreach($dias as $key) {
					$cual = $count%2;
					if($cual>0) { $odd = " class='odd' "; } else { $odd = ""; }
					if(!isset($ans_by_day["$key"])) {
						$ans_by_day["$key"]=0;
					}
					if(!isset($unans_by_day["$key"])) {
						$unans_by_day["$key"]=0;
					}
					if($answered > 0) {
						$percent_ans   = $ans_by_day["$key"]   * 100 / $answered;
					} else {
						$percent_ans = 0;
					}
					if($ans_by_day["$key"] >0) {
						$average_call_duration = $total_time_by_day["$key"] / $ans_by_day["$key"];
						$average_hold_duration = $total_hold_by_day["$key"] / $ans_by_day["$key"];
					} else {
						$average_call_duration = 0;
						$average_hold_duration = 0;
					}
					if($unanswered > 0) {
						$percent_unans = $unans_by_day["$key"] * 100 / $unanswered;
					} else {
						$percent_unans = 0;
					}
					$percent_ans   = number_format($percent_ans,  2);
					$percent_unans = number_format($percent_unans,2);
					$average_call_duration_print = seconds2minutes($average_call_duration);
					if($key<>"") {
					$linea_pdf = array($key,$ans_by_day["$key"],"$percent_ans ".$lang["$language"]['percent'],$unans_by_day["$key"],"$percent_unans ".$lang["$language"]['percent'],$average_call_duration_print,number_format($average_hold_duration,0),$login_by_day["$key"],$logout_by_day["$key"]);

					echo "<TR $odd>\n";
					echo "<TD>$key</TD>\n";
					echo "<TD>".$ans_by_day["$key"]."</TD>\n";
					echo "<TD>$percent_ans ".$lang["$language"]['percent']."</TD>\n";
					echo "<TD>".$unans_by_day["$key"]."</TD>\n";
					echo "<TD>$percent_unans".$lang["$language"]['percent']."</TD>\n";
					echo "<TD>".$average_call_duration_print." ".$lang["$language"]['minutes']."</TD>\n";
					echo "<TD>".number_format($average_hold_duration,0)." ".$lang["$language"]['secs']."</TD>\n";
					echo "<TD>".$login_by_day["$key"]."</TD>\n";
					echo "<TD>".$logout_by_day["$key"]."</TD>\n";
					echo "</TR>\n";
					$count++;
					$data_pdf[]=$linea_pdf;
					}
				}
				?>
			</TBODY>
			</TABLE>
			
			<?php 
				if($count>1) {
					print_exports($header_pdf,$data_pdf,$width_pdf,$title_pdf,$cover_pdf); 
				}
			?>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->

			<BR>
			
			<a name='2'></a>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['call_distrib_hour']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

			<TABLE class="table table-striped table-bordered bootstrap-datatable datatable responsive">
				<THEAD>
				<TR>
                    <TH><?php echo $lang["$language"]['hour']?></TH>
                    <TH><?php echo $lang["$language"]['answered']?></TH>
                    <TH><?php echo $lang["$language"]['percent_answered']?></TH>
                    <TH><?php echo $lang["$language"]['unanswered']?></TH>
                    <TH><?php echo $lang["$language"]['percent_unanswered']?></TH>
                    <TH><?php echo $lang["$language"]['avg_calltime']?></TH>
                    <TH><?php echo $lang["$language"]['avg_holdtime']?></TH>
                    <TH><?php echo $lang["$language"]['login']?></TH>
                    <TH><?php echo $lang["$language"]['logoff']?></TH>
				</TR>
				</THEAD>
				<TBODY>
				<?php 

				$header_pdf2=array($lang["$language"]['hour'],$lang["$language"]['answered'],$lang["$language"]['percent_answered'],$lang["$language"]['unanswered'],$lang["$language"]['percent_unanswered'],$lang["$language"]['avg_calltime'],$lang["$language"]['avg_holdtime'],$lang["$language"]['login'],$lang["$language"]['logoff']);
				$width_pdf2=array(25,23,23,23,23,25,25,20,20);
				$title_pdf2=$lang["$language"]['call_distrib_hour'];
				$data_pdf2 = array();

				$query_ans = "";
				$query_unans = "";
				$query_time="";
				$query_hold="";
				for($key=0;$key<24;$key++) {
					$cual = ($key+1)%2;
					if($cual>0) { $odd = " class='odd' "; } else { $odd = ""; }
					if(strlen($key)==1) { $key = "0".$key; }
					if(!isset($ans_by_hour["$key"])) {
						$ans_by_hour["$key"]=0;
						$average_call_duration = 0;
						$average_hold_duration = 0;
					} else {
						$average_call_duration = $total_time_by_hour["$key"] / $ans_by_hour["$key"];
						$average_hold_duration = $total_hold_by_hour["$key"] / $ans_by_hour["$key"];
					}
					if(!isset($unans_by_hour["$key"])) {
						$unans_by_hour["$key"]=0;
					}
					if($answered > 0) {
						$percent_ans   = $ans_by_hour["$key"]   * 100 / $answered;
					} else {
						$percent_ans = 0;
					}
					if($unanswered > 0) {
						$percent_unans = $unans_by_hour["$key"] * 100 / $unanswered;
					} else {
						$percent_unans = 0;
					}
					$percent_ans   = number_format($percent_ans,  2);
					$percent_unans = number_format($percent_unans,2);

					if(!isset($login_by_hour["$key"])) {
					    $login_by_hour["$key"]=0;
                    }
					if(!isset($logout_by_hour["$key"])) {
					    $logout_by_hour["$key"]=0;
                    }

					$linea_pdf2 = array($key,$ans_by_hour["$key"],"$percent_ans ".$lang["$language"]['percent'],$unans_by_hour["$key"],"$percent_unans ".$lang["$language"]['percent'],number_format($average_call_duration,0),number_format($average_hold_duration,0),$login_by_hour["$key"],$logout_by_hour["$key"]);

					echo "<TR $odd>\n";
					echo "<TD>$key</TD>\n";
					echo "<TD>".$ans_by_hour["$key"]."</TD>\n";
					echo "<TD>$percent_ans".$lang["$language"]['percent']."</TD>\n";
					echo "<TD>".$unans_by_hour["$key"]."</TD>\n";
					echo "<TD>$percent_unans".$lang["$language"]['percent']."</TD>\n";
					echo "<TD>".number_format($average_call_duration,0)." ".$lang["$language"]['secs']."</TD>\n";
					echo "<TD>".number_format($average_hold_duration,0)." ".$lang["$language"]['secs']."</TD>\n";
					echo "<TD>".$login_by_hour["$key"]."</TD>\n";
					echo "<TD>".$logout_by_hour["$key"]."</TD>\n";
					echo "</TR>\n";
					$gkey = $key+1;
					$query_ans  .="var$gkey=$key&val$gkey=".$ans_by_hour["$key"]."&";
					$query_unans.="var$gkey=$key&val$gkey=".$unans_by_hour["$key"]."&";
					$query_comb.= "var$gkey=$key%20".$lang["$language"]['hours']."&valA$gkey=".$ans_by_hour["$key"]."&valB$gkey=".$unans_by_hour["$key"]."&";
////////////////////////////////////////   DADOS PARA GR´FICO ///////////////////////////////////////////
$HORA_GRAFICO1 .="'".$key."h',";
//$ANS_GRAFICO1  .="'".$ans_by_hour["$key"]."',"; 
$ANS_GRAFICO1  .="'".$percent_ans."',"; 
//$UNS_GRAFICO1  .="'".$unans_by_hour["$key"]."',";
$UNS_GRAFICO1  .="'".$percent_unans."',";
/////////////////////////////////////////////////////////////////////////////////////////////////////////
					$query_time.="var$gkey=$key&val$gkey=".intval($average_call_duration)."&";

////////////////////////////////////////   DADOS PARA GR´FICO ///////////////////////////////////////////
$HORA_GRAFICO2 .="'".$key."h',";

$TEMP_GRAFICO2 .="'".intval($average_call_duration)."',"; 
/////////////////////////////////////////////////////////////////////////////////////////////////////////

					$query_hold.="var$gkey=$key&val$gkey=".intval($average_hold_duration)."&";
////////////////////////////////////////   DADOS PARA GR´FICO ///////////////////////////////////////////
$HORA_GRAFICO3 .="'".$key."h',";
$ESP_GRAFICO3  .="'".intval($average_hold_duration)."',";
/////////////////////////////////////////////////////////////////////////////////////////////////////////

					$data_pdf2[]=$linea_pdf2;
				}
				$query_ans.="title=".$lang["$language"]['answ_by_hour']."$graphcolor";
				$query_unans.="title=".$lang["$language"]['unansw_by_hour']."$graphcolor";
				$query_time.="title=".$lang["$language"]['avg_call_time_by_hr']."$graphcolor";
				$query_hold.="title=".$lang["$language"]['avg_hold_time_by_hr']."$graphcolor";
				$query_comb.="title=".$lang["$language"]['anws_unanws_by_hour']."$graphcolorstack&tagA=".$lang["$language"]['answered_calls']."&tagB=".$lang["$language"]['unanswered_calls'];
				?>

<!-- /////////////////////////////   GERAÇÃO GRAFICOS SEMANAIS //////////////////////////////////////////   -->
                                <?php
/////////////////////////////   TRADUZINDO DIA DA SEMANA ////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

                                $header_pdf3=array($lang["$language"]['day'],$lang["$language"]['answered'],$lang["$language"]['percent_answered'],$lang["$language"]['unanswered'],$lang["$language"]['percent_unanswered'],$lang["$language"]['avg_calltime'],$lang["$language"]['avg_holdtime'],$lang["$language"]['login'],$lang["$language"]['logoff']);
                                $width_pdf3=array(25,23,23,23,23,25,25,20,20);
                                $title_pdf3=$lang["$language"]['call_distrib_week'];
                                $data_pdf3 = array();


                                $query_ans="";
                                $query_unans="";
                                $query_time="";
                                $query_hold="";
                                for($key=0;$key<7;$key++) {
                                        $cual = ($key+1)%2;
                                        if($cual>0) { $odd = " class='odd' "; } else { $odd = ""; }
                                        if(!isset($total_time_by_dw["$key"])) {
                                                $total_time_by_dw["$key"]=0;
                                        }
                                        if(!isset($total_hold_by_dw["$key"])) {
                                                $total_hold_by_dw["$key"]=0;
                                        }
                                        if(!isset($ans_by_dw["$key"])) {
                                                $ans_by_dw["$key"]=0;
                                                $average_call_duration = 0;
                                                $average_hold_duration = 0;
                                        } else {
                                                $average_call_duration = $total_time_by_dw["$key"] / $ans_by_dw["$key"];
                                                $average_hold_duration = $total_hold_by_dw["$key"] / $ans_by_dw["$key"];
                                        }

                                        if(!isset($unans_by_dw["$key"])) {
                                                $unans_by_dw["$key"]=0;
                                        }
                                        if($answered > 0) {
                                                $percent_ans   = $ans_by_dw["$key"]   * 100 / $answered;
                                        } else {
                                                $percent_ans = 0;
                                        }
                                        if($unanswered > 0) {
                                                $percent_unans = $unans_by_dw["$key"] * 100 / $unanswered;
                                        } else {
                                                $percent_unans = 0;
                                        }
                                        $percent_ans   = number_format($percent_ans,  2);
                                        $percent_unans = number_format($percent_unans,2);

                                        if(!isset($login_by_dw["$key"])) {
                                            $login_by_dw["$key"]=0;
                    }
                                        if(!isset($logout_by_dw["$key"])) {
                                            $logout_by_dw["$key"]=0;
                    }

                                        $linea_pdf3 = array($dayp["$key"],$ans_by_dw["$key"],"$percent_ans ".$lang["$language"]['percent'],$unans_by_dw["$key"],"$percent_unans ".$lang["$language"]['percent'],number_format($average_call_duration,0),number_format($average_hold_duration,0),$login_by_dw["$key"],$logout_by_dw["$key"]);


                                        $gkey = $key + 1;
                                        $query_ans  .="var$gkey=".$dayp["$key"]."&val$gkey=".intval($ans_by_dw["$key"])."&";
///////////// SEMANA TRADUZIDA  ///////////////////

$DIA_GRAFICO  .="'".$dayp["$key"]."',";
//////////////////////////////////////////////////
$ANS_GRAFICO   .="'".intval($ans_by_dw["$key"])."',";
//////////////////////////////////////////////////

                                        $query_unans.="var$gkey=".$dayp["$key"]."&val$gkey=".intval($unans_by_dw["$key"])."&";
//////////////////////////////////////////////////
$UNANS_GRAFICO   .="'".intval($unans_by_dw["$key"])."',";
//////////////////////////////////////////////////

                                        $query_time.="var$gkey=".$dayp["$key"]."&val$gkey=".intval($average_call_duration)."&";
//////////////////////////////////////////////////
$TEMP_GRAFICO   .="'".intval($average_call_duration)."',";
//////////////////////////////////////////////////

                                        $query_hold.="var$gkey=".$dayp["$key"]."&val$gkey=".intval($average_hold_duration)."&";
//////////////////////////////////////////////////
$ESP_GRAFICO   .="'".intval($average_hold_duration)."',";
//////////////////////////////////////////////////


                                        $data_pdf3[]=$linea_pdf3;
                                }
                                ?>





			</TBODY>
			</TABLE>
			<?php 
				print_exports($header_pdf2,$data_pdf2,$width_pdf2,$title_pdf2,$cover_pdf2); 
//print_r($ESP_GRAFICO);
			?>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->

			<BR>
<!-- ////////////// GERAÇÃO GRAFICOS CHART //////////////  -->
            <script type="text/javascript">

                var options = {
                    responsive:true,
                    tooltipTemplate: "<%= value %> %",
                };
                var options2 = {
                    responsive:true,
                    tooltipTemplate: "<%= value %> Ligações",

                };
                var options3 = {
                    responsive:true,
                    tooltipTemplate: "<%= value %> Segundos",

                };


                var data = {
                    labels: [<?php echo $HORA_GRAFICO1;?>],
                    datasets: [
                        {
                            label: "Atendido",
                            fillColor: "#1571cd",
                            strokeColor: "#91c8ff",
                            highlightFill: "#91c8ff",
                            highlightStroke: "#1571cd",
                            data: [<?php echo $ANS_GRAFICO1;?>]
                        },

                    ]
                };

/////////////////////////////////////////////////////////////////////

                var data2 = {
                    labels: [<?php echo $HORA_GRAFICO1;?>],
                    datasets: [
                        {
                            label: "Não Atendido",
                            fillColor: "#ff0000",
                            strokeColor: "#ffb1b1",
                            highlightFill: "#ffb1b1",
                            highlightStroke: "#ff0000",
                            data: [<?php echo $UNS_GRAFICO1;?>]
                        }
]
                };
/////////////////////////////////////////////////////////////////////

                var data3 = {
                    labels: [<?php echo $HORA_GRAFICO2;?>],
                    datasets: [
                        {
                            label: "Atendido",
                            fillColor: "#1571cd",
                            strokeColor: "#91c8ff",
                            highlightFill: "#91c8ff",
                            highlightStroke: "#1571cd",
                            data: [<?php echo $TEMP_GRAFICO2;?>]
                        },
                    ]
                };
/////////////////////////////////////////////////////////////////////


                var data4 = {
                    labels: [<?php echo $HORA_GRAFICO3;?>],
                    datasets: [
                        {
                            label: "Total de chamadas",
                            fillColor: "#ff0000",
                            strokeColor: "#ffb1b1",
                            highlightFill: "#ffb1b1",
                            highlightStroke: "#ff0000",
                            data: [<?php echo $ESP_GRAFICO3;?>]
                        },
                    ]
                };
/////////////////////////////////////////////////////////////////////
                var data5 = {
                    labels: [<?php echo$DIA_GRAFICO;?>],
                    datasets: [
                        {
                            label: "Chamadas atendidas por dia da semana",
                            fillColor: "rgba(255, 199, 205, 0.2)",
                            strokeColor: "#ff7b7b",
                            pointColor: "#ff0000",
                            pointStrokeColor: "#ffb1b1",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "#ffb1b1",
                            data: [<?php echo$ANS_GRAFICO;?>]
                        },
                        {
                            label: "Chamadas não atendidas por dia da semana",
                            fillColor: "rgba(182, 219, 255, 0.2)",
                            strokeColor: "#1571cd",
                            pointColor: "#1571cd",
                            pointStrokeColor: "#91c8ff",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "rgba(151,187,205,1)",
                            data: [<?php echo$UNANS_GRAFICO;?>]
                        }
                    ]
                };
/////////////////////////////////////////////////////////////////////
                var data6 = {
                    labels: [<?php echo$DIA_GRAFICO;?>],
                    datasets: [
                        {
                            label: "Tempo médio de ligação por dia da semana",
                            fillColor: "rgba(152, 255, 205, 0.2)",
                            strokeColor: "#00c35c",
                            pointColor: "#00c35c",
                            pointStrokeColor: "#49bf80",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "rgba(151,187,205,1)",
                            data: [<?php echo$TEMP_GRAFICO;?>]
                        },
                        {
                            label: "Tempo médio de espera por dia da semana",
                            fillColor: "rgba(217, 199, 49, 0.2)",
                            strokeColor: "#f1bf00",
                            pointColor: "#f1bf00",
                            pointStrokeColor: "#f2e7ba",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "rgba(151,187,205,1)",
                            data: [<?php echo$ESP_GRAFICO;?>]
                        }
                    ]
                };

                window.onload = function(){
                    var ctx = document.getElementById("GraficoBarra").getContext("2d");
                    var BarChart = new Chart(ctx).Bar(data, options);

                    var ctx2 = document.getElementById("GraficoBarra2").getContext("2d");
                    var BarChart = new Chart(ctx2).Bar(data2, options);

                    var ctx3 = document.getElementById("GraficoBarra3").getContext("2d");
                    var BarChart = new Chart(ctx3).Bar(data3, options3);

                    var ctx4 = document.getElementById("GraficoBarra4").getContext("2d");
                    var BarChart = new Chart(ctx4).Bar(data4, options3);

                    var ctx5 = document.getElementById("GraficoLine1").getContext("2d");
                    var LineChart = new Chart(ctx5).Line(data5, options2);
		    document.getElementById('linha1').innerHTML = LineChart.generateLegend();

                    var ctx6 = document.getElementById("GraficoLine2").getContext("2d");
                    var LineChart = new Chart(ctx6).Line(data6, options3);

		    document.getElementById('linha2').innerHTML = LineChart.generateLegend();
                }
            </script>


				<hr>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  Situação Das Chamadas</h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">


<!-- //////////////////////////////////////////////////////   -->
			<TABLE width='97%' border="0">
			<TBODY>
			<TR>
				<TD width='50%' ><h3 align="center"> Atendidas</h3>
        <div class="box-chart">

            <canvas id="GraficoBarra" style="width:100%;"></canvas>
        </div>
				</TD>
				<TD width='50%'><h3 align="center"> Não Atendidas</h3>
        <div class="box-chart">

            <canvas id="GraficoBarra2" style="width:100%;"></canvas>
        </div>
				</TD>
			</TR>
			</TBODY>
			</TABLE>
<!-- //////////////////////////////////////////////////////   -->
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->
	<br>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  Tempo Médio</h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

                        <TABLE width='97%' border="0">
			<TBODY>
                        <TR>
                                <TD width='50%' ><h3 align="center"> Tempo Médio De Ligações Por Hora</h3>
        <div class="box-chart">

            <canvas id="GraficoBarra3" style="width:100%;"></canvas>
        </div>
                                </TD>
                                <TD width='50%'><h3 align="center"> Tempo Médio de Espera Por Hora</h3>
        <div class="box-chart">

            <canvas id="GraficoBarra4" style="width:50%;"></canvas>
        </div>
                                </TD>
                        </TR>
			</TBODY>
                        </TABLE>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->

			<BR>

			<a name='3'></a>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['call_distrib_week']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-12">

			<TABLE width='99%' cellpadding=1 cellspacing=1 border=0 class='sortable table table-striped table-bordered responsive' id='table3'>
				<THEAD>
				<TR>
                    <TH><?php echo $lang["$language"]['day']?></TH>
                    <TH><?php echo $lang["$language"]['answered']?></TH>
                    <TH><?php echo $lang["$language"]['percent_answered']?></TH>
                    <TH><?php echo $lang["$language"]['unanswered']?></TH>
                    <TH><?php echo $lang["$language"]['percent_unanswered']?></TH>
                    <TH><?php echo $lang["$language"]['avg_calltime']?></TH>
                    <TH><?php echo $lang["$language"]['avg_holdtime']?></TH>
                    <TH><?php echo $lang["$language"]['login']?></TH>
                    <TH><?php echo $lang["$language"]['logoff']?></TH>
				</TR>
				</THEAD>
				<TBODY>
				<?php 

				$header_pdf4=array($lang["$language"]['day'],$lang["$language"]['answered'],$lang["$language"]['percent_answered'],$lang["$language"]['unanswered'],$lang["$language"]['percent_unanswered'],$lang["$language"]['avg_calltime'],$lang["$language"]['avg_holdtime'],$lang["$language"]['login'],$lang["$language"]['logoff']);
				$width_pdf4=array(25,23,23,23,23,25,25,20,20);
				$title_pdf4=$lang["$language"]['call_distrib_week'];
				$data_pdf4 = array();


				$query_ans="";
				$query_unans="";
				$query_time="";
				$query_hold="";
				for($key=0;$key<7;$key++) {
					$cual = ($key+1)%2;
					if($cual>0) { $odd = " class='odd' "; } else { $odd = ""; }
					if(!isset($total_time_by_dw["$key"])) {
						$total_time_by_dw["$key"]=0;
					}
					if(!isset($total_hold_by_dw["$key"])) {
						$total_hold_by_dw["$key"]=0;
					}
					if(!isset($ans_by_dw["$key"])) {
						$ans_by_dw["$key"]=0;
						$average_call_duration = 0;
						$average_hold_duration = 0;
					} else {
						$average_call_duration = $total_time_by_dw["$key"] / $ans_by_dw["$key"];
						$average_hold_duration = $total_hold_by_dw["$key"] / $ans_by_dw["$key"];
					}

					if(!isset($unans_by_dw["$key"])) {
						$unans_by_dw["$key"]=0;
					}
					if($answered > 0) {
						$percent_ans   = $ans_by_dw["$key"]   * 100 / $answered;
					} else {
						$percent_ans = 0;
					}
					if($unanswered > 0) {
						$percent_unans = $unans_by_dw["$key"] * 100 / $unanswered;
					} else {
						$percent_unans = 0;
					}
					$percent_ans   = number_format($percent_ans,  2);
					$percent_unans = number_format($percent_unans,2);

					if(!isset($login_by_dw["$key"])) {
					    $login_by_dw["$key"]=0;
                    }
					if(!isset($logout_by_dw["$key"])) {
					    $logout_by_dw["$key"]=0;
                    }

					$linea_pdf4 = array($dayp["$key"],$ans_by_dw["$key"],"$percent_ans ".$lang["$language"]['percent'],$unans_by_dw["$key"],"$percent_unans ".$lang["$language"]['percent'],number_format($average_call_duration,0),number_format($average_hold_duration,0),$login_by_dw["$key"],$logout_by_dw["$key"]);

					echo "<TR $odd>\n";
					echo "<TD>".$dayp["$key"]."</TD>\n";
					echo "<TD>".$ans_by_dw["$key"]."</TD>\n";
					echo "<TD>$percent_ans".$lang["$language"]['percent']."</TD>\n";
					echo "<TD>".$unans_by_dw["$key"]."</TD>\n";
					echo "<TD>$percent_unans".$lang["$language"]['percent']."</TD>\n";
					echo "<TD>".number_format($average_call_duration,0)." secs</TD>\n";
					echo "<TD>".number_format($average_hold_duration,0)." secs</TD>\n";
					echo "<TD>".$login_by_dw["$key"]."</TD>\n";
					echo "<TD>".$logout_by_dw["$key"]."</TD>\n";
					echo "</TR>\n";
					$gkey = $key + 1;
					$query_ans  .="var$gkey=".$dayp["$key"]."&val$gkey=".intval($ans_by_dw["$key"])."&";
					$query_unans.="var$gkey=".$dayp["$key"]."&val$gkey=".intval($unans_by_dw["$key"])."&";
					$query_time.="var$gkey=".$dayp["$key"]."&val$gkey=".intval($average_call_duration)."&";
					$query_hold.="var$gkey=".$dayp["$key"]."&val$gkey=".intval($average_hold_duration)."&";
					$data_pdf4[]=$linea_pdf4;
				}
				$query_ans.="title=".$lang["$language"]['answ_by_day']."$graphcolor";
				$query_unans.="title=".$lang["$language"]['unansw_by_day']."$graphcolor";
				$query_time.="title=".$lang["$language"]['avg_call_time_by_day']."$graphcolor";
				$query_hold.="title=".$lang["$language"]['avg_hold_time_by_day']."$graphcolor";
				?>
			</TBODY>
			</TABLE>
			<?php 
				print_exports($header_pdf4,$data_pdf4,$width_pdf4,$title_pdf4,$cover_pdf4); 
			?>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->

			<BR>
    <div class="row">
        <div class="col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-list"></i>  <?php echo $lang["$language"]['call_distrib_week']?></h2>

                </div>
                <div class="box-content">
                    <div class="row">
                        <div class="col-md-6">

				<h2 align="center"> Estatisticas Da Situação De Chamadas Por Dia Da Semana - (LIGAÇÕES)</h2><br>
        <div class="box-chart">

            <canvas id="GraficoLine1" style="width:100%;"></canvas>
        </div>
<br>
<br>
<div id="linha1" class="chart-legend"></div>

                        </div>
                        <div class="col-md-6">

				<TD><h2 align="center"> Estatisticas De Tempo De Chamadas Por Dia Da Semana - (SEGUNDOS)</h2><br>
        <div class="box-chart">

            <canvas id="GraficoLine2" style="width:100%;"></canvas>
        </div>
<br>
<br>
<div id="linha2" class="chart-legend"></div>
</div>
                    </div>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->


</div>
</div>

</body>
<?php require_once('footer_conf.php');?>
</html>
