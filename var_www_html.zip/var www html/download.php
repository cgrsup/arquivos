<?php
    if (isset($_GET['location'])) {

        if ($_GET['location'] == "issabel") {
            if (isset($_GET['file'])) {
                $file = '/var/www/'.$_GET['file'].'.zip';

                header('Pragma: public');
                header('Expires: 0');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Cache-Control: private', false);
                header("Content-Transfer-Encoding: binary");
                header('Content-Disposition: attachment; filename="'.$file.'";');
                header("Content-Type: application/zip");
                header('Content-Length: ' . filesize($file));
    
                // read the file from disk
                $chunkSize = 1024 * 1024;
                $handle = fopen($file, 'rb');
                while (!feof($handle))
                {
                    $buffer = fread($handle, $chunkSize);
                    echo $buffer;
                    ob_flush();
                    flush();
                }
                
                fclose($handle);
                exit;
            } else {
                include('build/index.html');
            }
        }
    }
?>
